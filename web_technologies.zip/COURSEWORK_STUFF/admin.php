<?php
 session_start();
 if(!isset($_SESSION['loggedin'])) header("Location: session.php");
 if($_SESSION['loggedin']===FALSE) header("Location: session.php");
 if($_SESSION['admin']==0) header("Location: session.php");
 if (isset($_POST["submit"])){
     $_SESSION['submitted']=TRUE;
     header("Location: submit.php");
     }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Page</title>
    <link rel="stylesheet" href="adminstyle.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
       
        
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
       <div class="navbar-nav">
         <a class="nav-item nav-link active" href="mainweb.html">Home</a>
         <a class="nav-item nav-link" href="session.php">Login</a>
         <a class="nav-item nav-link" href="weather.html">Weather</a>
         <a class="nav-item nav-link disabled" href="cv.html">CV</a>
       </div>
     </div>
   </nav>


    <div class="boxes">
    <h3>Welcome to the Admin Page</h3>
    <a href = "submit.php"><button>Add Library Book</button></a>
   <a href = "list.php"> <button>View Library Books</button></a>
   <form action="logout.php" method="POST">
 <input type="submit" name="logout" value="Log out">
 </form>
    </div>
    </body>
    </html>


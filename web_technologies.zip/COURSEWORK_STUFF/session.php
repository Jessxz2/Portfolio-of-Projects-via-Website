<?php
  session_start();
  if(isset($_SESSION['loggedin'])) header("Location: secret.php");
  ?>



<!DOCTYPE html>
<head>
    
    <title>Login Form</title>
    <link rel="stylesheet" href="sessionstyle.css">
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
               
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
       <div class="navbar-nav">
         <a class="nav-item nav-link active" href="mainweb.html">Home</a>
         <a class="nav-item nav-link" href="session.php">Login</a>
         <a class="nav-item nav-link" href="weather.html">Weather</a>
         <a class="nav-item nav-link disabled" href="cv.html">CV</a>
       </div>
     </div>
   </nav>
<!-- code to retrieve info from user-->
<form action="login.php" method="post">
    <label>Username:</label><br>
    <input type="text" name="username" required><br>
    <label>Password:</label><br>
    <input type="password" name="password" required><br>
    <input type="submit" name="login" value="Login">
</form>

</body>
</html>


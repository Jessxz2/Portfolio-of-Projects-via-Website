 <?php

session_start();
if($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["submit"])){
    //getting the data from the form
    $title = $_POST['title'];
    $author = $_POST['author'];
    $isbn = $_POST['isbn'];
    $publishedDate= $_POST['published_date'];
    $description = $_POST['description'];

    
    //creating an array with the data
    $newBook = [$title, $author, $isbn, $publishedDate, $description];

     // Open CSV file and putting the array in the csv file, and then close it
     $file = fopen('books.csv', 'a');

     fputcsv($file, $newBook);

     fclose($file);
     // checking if every label in the form is filled in with something when submit button is pressed
    if(isset($_POST["submit"])){
        if(!empty($_POST["title"]) &&
           !empty($_POST["author"]) &&
           !empty($_POST["isbn"]) &&
           !empty($_POST["published_date"]) &&
           !empty($_POST["description"])){

     // indicating that the book was successfully added
     $_SESSION['bookAdded'] = true;
           }
        }
} 
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Library Book</title>
        <link rel="stylesheet" href="submitstyle.css">
    </head>
    <body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
       
        
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
       <div class="navbar-nav">
         <a class="nav-item nav-link active" href="mainweb.html">Home</a>
         <a class="nav-item nav-link" href="session.php">Login</a>
         <a class="nav-item nav-link" href="weather.html">Weather</a>
         <a class="nav-item nav-link disabled" href="cv.html">CV</a>
       </div>
     </div>
   </nav>

        <h3><u> Welcome to The Library!</u></h3>
        <h4> Add a new book to the system:</h4>
        
        <!-- included the 'pattern' attribute to ensure that certain characters can be entered in each label, 
        and not just anything .-->
        <form action = "submit.php" method = "POST">
            <label>Title:</label><br>
            <input type = "text" name = "title" placeholder="e.g. Computer Science" pattern="[a-zA-Z]*"><br>
            <label>Author:</label><br>
            <input type = "text" name = "author" placeholder="e.g. Robin Nixon" pattern="[a-zA-Z]*"><br>
            <label>ISBN::</label><br>
            <input type = "text" name = "isbn" placeholder="e.g. 1234567890123" maxlength="13" pattern="[0-9]{13}"title="Enter 13 digits"><br>
            <label>Published Date:</label><br>
            <input type = "text" name = "published_date" placeholder="e.g. 2023" maxlength="4" pattern="[0-9]{4}" title="Enter 4 digits"><br>
            <label>Description:</label><br>
            <input type = "text" name = "description" placeholder="max 250 characters" maxlength="250"pattern="[a-zA-Z]*"><br>
            <input type = "submit" name = "submit" value = "Submit"><br>
    </body>
</html>
<?php
    // Display a message saying that book has been added

    if (isset($_SESSION['bookAdded']) && $_SESSION['bookAdded'] === true) {
        header("Location: book_added.php");
        echo "Book successfully added to the library!"; 
        $_SESSION['bookAdded'] = false;
    }

    ?>


    



    
<?php
session_start();
// retrieve the isbn
$isbn = isset($_GET['isbn']) ? $_GET['isbn'] : '';

// Read the data from the file
$books = [];
if (($handle = fopen("books.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        // Check if the isbn matches
        if (!empty($data[2]) && $data[2] === $isbn) {
            $book = [
                'title' => $data[0],
                'author' => $data[1],
                'isbn' => $data[2],
                'published_date' => $data[3],
                'description' => $data[4],
            ];

            break; // stop searching once we found the matching book
        }
    }
    fclose($handle);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Details</title>
    <link rel="stylesheet" href="displaystyle.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
       
        
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
       <div class="navbar-nav">
         <a class="nav-item nav-link active" href="mainweb.html">Home</a>
         <a class="nav-item nav-link" href="session.php">Login</a>
         <a class="nav-item nav-link" href="weather.html">Weather</a>
         <a class="nav-item nav-link disabled" href="cv.html">CV</a>
       </div>
     </div>
   </nav>


    <!-- displays the books-->
    <?php if (isset($book)): ?>
        <h2><?php echo $book['title']; ?></h2>
        <p>Author: <?php echo $book['author']; ?></p>
        <p>ISBN: <?php echo $book['isbn']; ?></p>
        <p>Published Date: <?php echo $book['published_date']; ?></p>
        
        <input type="checkbox" id="showDescription" style="display: none;">
        <label class="toggle-btn" for="showDescription">Show Description</label>
        <div class= "description-container">
        <p>Description: <?php echo $book['description']; ?></p>
    <?php else: ?>
        <p>Book not found.</p>
    <?php endif; ?>
    

</body>
</html>


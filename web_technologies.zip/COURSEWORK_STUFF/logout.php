<?php
//goes back to login page
 session_start();
 session_destroy();
 header("Location: session.php");
 exit();
 ?>

<?php
session_start();


// Reas the data from the file
$books = [];
if (($handle = fopen("books.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        // Skip empty lines
        if (!empty($data[0])) {
            $books[] = [
                'title' => $data[0],
                'isbn' => $data[2],
            ];
        }
    }
    fclose($handle);
}
?>

<!DOCTYPE html>
<head>
    <title>List of Books</title>
    <link rel="stylesheet" href="liststyle.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
       
        
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
       <div class="navbar-nav">
         <a class="nav-item nav-link active" href="mainweb.html">Home</a>
         <a class="nav-item nav-link" href="session.php">Login</a>
         <a class="nav-item nav-link" href="weather.html">Weather</a>
         <a class="nav-item nav-link disabled" href="cv.html">CV</a>
       </div>
     </div>
   </nav>



    <h2>List of Books</h2>

    <?php if (!empty($books)): ?>
        <ul>
            <!-- goes through each book and displays it in display.php-->
            <?php foreach ($books as $book): ?>
                <li>
                    <a href="display.php?isbn=<?php echo $book['isbn']; ?>">
                        <?php echo $book['title']; ?>
                    </a>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p>No books available.</p>
    <?php endif; ?>

</body>
</html>
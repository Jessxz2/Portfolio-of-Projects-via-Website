<?php
 session_start();
 //ensures that user i only able to log in when the button is pressed.
 if(!isset($_SESSION['loggedin'])) header("Location: session.php");
 if($_SESSION['loggedin']===FALSE) header("Location: session.php");
?>




<!DOCTYPE html>
 <html>
<head>
    <title>Secret Area</title>
    <link rel="stylesheet" href="secretstyle.css">
</head>
 <body>
 <nav class="navbar navbar-expand-lg navbar-light bg-light">
       
        
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
       <div class="navbar-nav">
         <a class="nav-item nav-link active" href="mainweb.html">Home</a>
         <a class="nav-item nav-link" href="session.php">Login</a>
         <a class="nav-item nav-link" href="weather.html">Weather</a>
         <a class="nav-item nav-link disabled" href="cv.html">CV</a>
       </div>
     </div>
   </nav>
 Welcome to the private message area for
 <?php echo $_SESSION['username'] ?>
 <h1>Messages:</h1>
 <!-- Log out button to enable user to log out-->
 <a href = "list.php"> <button>View Library Books</button></a>
 <form action="logout.php" method="POST">
 <input type="submit" name="logout" value="Log out">
 </form>

 <p>&copy; 2021 Private Message Limited</p>
 </body>
 </html>

 


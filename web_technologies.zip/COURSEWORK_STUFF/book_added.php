<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Library Book</title>
</head>
<body>
  <!--go back buttonn allows user to go to submit.php and add a new book if they wished-->
    <h1>Your new book has been successfully added to the Library!<h1>
  <a href= "submit.php"><button>Go back</button></a>
</body>

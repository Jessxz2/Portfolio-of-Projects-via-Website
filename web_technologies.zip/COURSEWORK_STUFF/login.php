
<?php
 session_start();
 if (isset($_SESSION['loggedin'])){
     header("Location: secret.php");
 }
 // go through the CSV and get the data
 $users = [];
if (($handle = fopen("users.csv", "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
     $users[$data[0]] = array("password"=>$data[1], "admin"=>$data[2]);
    }
    fclose($handle);
    }
    //Get the data from the form
    $u = $_POST['username'];
    $p = $_POST['password'];
    // check to see if it matches the database
    if(isset($users[$u]) && $users[$u]['password'] == $p ) {
     $_SESSION['loggedin']=TRUE;
     $_SESSION['username']=$u;

     if($users[$u]['admin']==1){
         $_SESSION['admin']=TRUE;
         $_SESSION['username']=$u;
         header("Location: admin.php");
     } else{
     header("Location: secret.php");
     }
 }
    else{
     header("Location: session.php");
    }


     
    
  
?>


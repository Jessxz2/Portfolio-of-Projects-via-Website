<?php
 // Assume that details for the CSC-20021 module are read from a database and populated into the
//following variables
 $id="CSC-20021";
 $name ="Web Technologies";
 $year = "2";
?>
<!DOCTYPE html>
<html>
 <head>
 <title>ID-NAME – TODO: Replace ID and NAME with the values of the $id and $name variables</title>
 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitterbootstrap/3.3.6/css/bootstrap.min.css">
 </head>
 <body class="container-fluid">
 <br>
 <div>
 <label>Id</label>: ID – TODO: Replace ID with the value of the $id variable
 </div>
 <div>
 <label>Name</label>: NAME - TODO: Replace NAME with the value of the $name variable
 </div>
 <div>
 <label>Year</label>: YEAR - TODO: Replace YEAR with the value of the $year variable
 </div>
</body>
</html>